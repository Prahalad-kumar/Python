# Taking input
age = int(input("Enter your age: "))

# Determine if the person is eligible to vote
if age >= 18:
    print("You are eligible to vote.")
else:
    print("You are not eligible to vote.")
